# Stick-figure reels: a Claude skill

This skill lets Claude make short vertical stick-figure reels: white pictogram figures on a dark stage, one red
accent, small clean type. It's the style and method behind the Instagram page @islamicstickreminders.

Claude draws every frame in code and hands you a finished MP4 with sound, plus a caption ready to paste.
Reels that quote the Qur'an can also play the recitation of the exact words on the end card.

## What you need

- A Claude plan that supports skills (Pro, Max, Team or Enterprise), with code execution turned on.
- Or Claude Code / Cowork.

## Install it

1. In Claude, open **Customize → Skills** (on some versions: **Settings → Capabilities → Skills**).
2. Upload `stick-figure-reels.zip` as it is. Don't unzip it first.
3. Turn the skill on.

Each person uploads it to their own account.

## Use it

Start a new chat and ask for a reel. For example:

- "Make a stick-figure reel: two men can't sleep at 2 AM. One scrolls, one does dhikr."
- "Make a '3 things' reel about du'a times that aren't rejected, with the hadith sources."
- "Make a stick-figure reel about calling your mom, ending on Qur'an 17:24 with the recitation."

Claude sets up the engine, shows you test frames if you want to approve the look, then renders the video,
adds sound and gives you the MP4 and the caption. A reel usually takes several minutes to render.

Tips:
- Say what feeling the viewer is living through. The reels that work start from one.
- Ask for your own colours or your page's tag in the hashtags if you want the look to be yours.
- For Qur'an reels, if Claude can't download the recitation itself, it will ask you to download the ayah
  from everyayah.com (Mishary Alafasy) and attach it.

## What's inside

- `SKILL.md`: the method and rules Claude follows.
- `engine/`: the Python renderer, sound library, recitation mixer, tools and six example reels.
- `engine/fonts/`: Amiri and IBM Plex Mono, both under the SIL Open Font License (see `engine/licenses/`).
