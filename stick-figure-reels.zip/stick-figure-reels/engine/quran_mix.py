"""Lay an Alafasy recitation over the end of a Qur'an reel, duck the SFX under it, and mux to out/<name>.mp4.
Add a CFG entry per reel: name (output file stem), file (SSSAAA in audio_src/hq), seg (start, end seconds of the
relevant words inside that mp3), start (when the recitation starts in the reel), optional fo (fade-out), duck,
keep_video_len (never shorten the video). Run: python3 quran_mix.py vXX. Needs out/vXX_silent.mp4 + out/vXX_audio.wav."""
import json, os, re, subprocess, sys
import numpy as np
from scipy.io import wavfile

SR = 48000
HERE = os.path.dirname(os.path.abspath(__file__))
if os.path.exists(os.path.join(HERE, 'bin', 'ffmpeg')):
    os.environ['PATH'] = os.path.join(HERE, 'bin') + os.pathsep + os.environ.get('PATH', '')


def media_dur(path):
    """duration in seconds, read from ffmpeg's own banner (works without ffprobe)."""
    err = subprocess.run(['ffmpeg', '-i', path], capture_output=True, text=True).stderr
    h, m, s = re.search(r'Duration: (\d+):(\d+):([\d.]+)', err).groups()
    return int(h) * 3600 + int(m) * 60 + float(s)

CFG = {
    # examples (add your own; the mp3 must be in audio_src/hq as SSSAAA.mp3):
    'v67': dict(name='Twenty_One', file='017023', seg=(27.2, 34.15), start=1.7, fo=0.15, duck=0.65, keep_video_len=True),
    'v63': dict(name='Same_Word', file='036082', seg=(9.12, 16.75), start=1.82, fo=0.15, duck=0.65),
}
TAIL = 0.45


def load_rec(f, a, b, fo_s=0.25):
    raw = subprocess.run(['ffmpeg', '-v', 'error', '-ss', str(a), '-to', str(b), '-i', f'audio_src/hq/{f}.mp3',
                          '-f', 'f32le', '-ac', '2', '-ar', str(SR), '-'], capture_output=True).stdout
    x = np.frombuffer(raw, np.float32).reshape(-1, 2).copy()
    n = len(x)
    fi = int(0.06 * SR)
    fo = int(fo_s * SR)
    x[:fi] *= np.linspace(0, 1, fi)[:, None]
    x[-fo:] *= np.linspace(1, 0, fo)[:, None]
    return x


def load_cfg_rec(c):
    """one ayah cut (file + seg), or several cuts in a row (parts) with a short gap between them."""
    if 'parts' not in c:
        return load_rec(c['file'], *c['seg'], c.get('fo', 0.25))
    gap = np.zeros((int(c.get('gap', 0.25) * SR), 2), np.float32)
    out = []
    for k, (f, (a, b)) in enumerate(c['parts']):
        if k:
            out.append(gap)
        out.append(load_rec(f, a, b))
    return np.vstack(out)


def rec_dur(v):
    c = CFG[v]
    if 'parts' in c:
        return sum(b - a for _, (a, b) in c['parts']) + c.get('gap', 0.25) * (len(c['parts']) - 1)
    a, b = c['seg']
    return b - a


def new_dur(v):
    return round(CFG[v]['start'] + rec_dur(v) + TAIL, 2)


def mix(v):
    c = CFG[v]
    D = new_dur(v)
    if c.get('keep_video_len'):
        vd0 = media_dur(f'out/{v}_silent.mp4')
        D = max(D, round(vd0, 2))
    sr, sfx = wavfile.read(f'out/{v}_audio.wav')
    sfx = sfx.astype(np.float32) / 32767
    n = int(D * SR)
    if len(sfx) < n:
        sfx = np.vstack([sfx, np.zeros((n - len(sfx), 2), np.float32)])
    sfx = sfx[:n]
    t = np.arange(n) / SR
    duck = 1 - c.get('duck', 0.8) * np.clip((t - (c['start'] - 0.3)) / 0.3, 0, 1)
    out = sfx * 0.42 * duck[:, None]
    rec = load_cfg_rec(c)
    i = int(c['start'] * SR)
    m = min(len(rec), n - i)
    out[i:i + m] += rec[:m] * 1.6
    fo = int(0.2 * SR)
    out[-fo:] *= np.linspace(1, 0, fo)[:, None]
    out = np.tanh(out * 1.3) / np.tanh(1.3)
    out = out / (np.abs(out).max() + 1e-9) * 10 ** (-1.5 / 20)
    wavfile.write(f'out/{v}_final.wav', SR, (out * 32767).astype(np.int16))
    vd = media_dur(f'out/{v}_silent.mp4')
    vf = f'tpad=stop_mode=clone:stop_duration={max(0.0, D - vd) + 0.1:.2f}'
    subprocess.run(['ffmpeg', '-loglevel', 'error', '-y', '-i', f'out/{v}_silent.mp4', '-i', f'out/{v}_final.wav',
                    '-vf', vf, '-t', str(D), '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-pix_fmt', 'yuv420p',
                    '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', f"out/{c['name']}.mp4"], check=True)
    return D


if __name__ == '__main__':
    which = sys.argv[1:] or list(CFG)
    if which[0] == 'durs':
        for v in CFG:
            print(v, new_dur(v))
    else:
        for v in which:
            print(CFG[v]['name'], mix(v))
