#!/bin/bash
# One-time setup. Run from anywhere: bash <engine folder>/setup.sh
cd "$(dirname "$0")"
PKGS="skia-python numpy scipy pillow uharfbuzz"
pip install -q $PKGS 2>/dev/null || pip install -q --break-system-packages $PKGS
if ! command -v ffmpeg >/dev/null 2>&1; then
  # no system ffmpeg: use the static build that ships inside the imageio-ffmpeg wheel
  pip install -q imageio-ffmpeg 2>/dev/null || pip install -q --break-system-packages imageio-ffmpeg
  mkdir -p bin && ln -sf "$(python3 -c 'import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())')" bin/ffmpeg
  echo "ffmpeg: using engine/bin/ffmpeg. In shell commands, first run:  export PATH=\"$PWD/bin:\$PATH\""
fi
mkdir -p out test
python3 -c "import skia, numpy, scipy, uharfbuzz; print('python deps ok')"
PATH="$PWD/bin:$PATH" ffmpeg -version | head -1
