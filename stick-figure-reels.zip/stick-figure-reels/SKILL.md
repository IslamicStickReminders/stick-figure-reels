---
name: stick-figure-reels
description: Make short vertical stick-figure reels with a message (two figures, one choice, a reveal) as finished MP4 videos with sound, optional Qur'an recitation, and a ready-to-post caption. Use when someone asks for a stick-figure reel, a minimalist pictogram video, a reminder reel, or a two-figure contrast video for Instagram, TikTok or Shorts.
---

# Stick-figure reels

Short vertical reels (1080×1920, 30 fps): white pictogram figures on a dark charcoal stage, one muted red accent,
small wide-tracked type, soft floor reflections. The style and method come from the Instagram page
@islamicstickreminders. Everything is drawn in code by the engine in `engine/` next to this file, so the
result is a finished video, not a prompt or a storyboard.

Deliver **finished MP4s plus a paste-ready caption**. Never stop at a script.

---

## 1. Set up (once per chat)

1. Copy the engine to a work folder and install it:
   ```bash
   cp -r "${CLAUDE_SKILL_DIR}/engine" ~/reels   # or the engine/ folder next to this SKILL.md
   cd ~/reels && bash setup.sh
   ```
   If setup says it is using `engine/bin/ffmpeg`, run `export PATH="$HOME/reels/bin:$PATH"` in each shell
   command that calls ffmpeg (the Python tools find it on their own).
2. Smoke test: `cp examples/v73_heavy.py . && python3 v73_heavy.py stills 15.6`, then look at
   `test/v73/t15.60.png`.

All commands run from the work folder. Each reel is one script next to the engine (`from kit2 import *` or
`from formula import *`). `examples/` holds six finished reels to copy from.

Rendering takes minutes. Run full renders in the background and check back (see step 5 in section 6).

---

## 2. What makes these reels work

These come from a page where a few reels went viral and many didn't. Keep all of them.

- **Start from an emotional reality** the viewer is living right now: can't sleep at 2 AM, missing your mom's
  calls, grief, a prayer that hasn't been answered for years, laid off, not speaking to your brother. The header
  names the feeling in plain words. The picture is that feeling made visible.
- **Two people, same situation; only the choice differs.** Same river, same storm, same phone call.
- **The losing label is a reason the viewer would defend.** "DOESN'T WANT TO BE A HYPOCRITE", "WANTS HIM TO CALL
  FIRST". Never a lazy reason like "snoozes".
- **The world answers the act.** The viewer discovers a rule in the first seconds (a stone rises under every
  step; every call lays a plank across the gap) and then watches whether the other one finds it. Two figures
  just doing two different things is not enough.
- **One keeps doing it; the other almost does and pulls back.** Walks to the edge and backs off, picks up the
  phone and puts it down.
- **The ending reveals something that was already true**, gently, as irony the viewer can smile at, not a
  scolding. Write a new ending line every time. Don't reuse a template like "He was waiting for X before he'd Y".
- **One object, few props.** A river, a ladder, a door, a scale.
- **Clear without the text.** Cover the words: if you can't tell what happened, it failed.
- **The first frame states the contrast.** No title card, no build-up, no fade-in.
- **Short.** Two-lane reels run about 9.5–10 s. The end card holds about 1 second once fully up (longer only if
  a recitation needs it). Viewers drop off before slow payoffs.

If the person you're making reels for has their own rules or corrections, those win. Write down what they tell
you and follow it in every later reel. When they ask for a change, change only that.

### Religious content (when a reel cites the Qur'an or hadith)
- Verify every ayah on quran.com and every hadith on sunnah.com: exact collection and number, and the grade for
  anything outside Bukhari and Muslim. Qur'an or sahih/hasan hadith only. Never quote from memory. If a solid
  source can't be found, say so instead of forcing one.
- A Qur'an end card plays the recitation of **only the relevant words**. A hadith end card has no recitation.
- Don't depict prophets. Never put a commended act on the losing side. Never preachy: the picture makes the
  point, the end card confirms it.

---

## 3. House style (the engine already does this; don't fight it)

- Radial charcoal background, vignette, film grain, short soft floor reflections.
- Matte and flat-lit. Light appears only as a story event (`light_pool`, `beam`: the world answering), never as
  decorative glow or neon.
- Figures: chunky white pictograms (`Figure(h)`; near limbs WHITE, far limbs FAR grey), big round head, no face.
- One accent: `RED` (a label dot, a burst, bricks, a stain, a clock). Props are greys.
- Type: IBM Plex Mono, uppercase, wide tracking, small. Arabic with `arabic()` (Amiri, properly shaped).
- To give a page its own look, change the colour constants at the top of `nv.py` (BG_IN, BG_OUT, WHITE, RED)
  and keep everything else.

---

## 4. Formats

### A. Two-lane contrast (the format of the viral reels)
See `examples/v69_callfirst.py` (hadith) and `examples/v67_twentyone.py` (Qur'an with recitation).
- Lanes: floor at y 930 (top, the one who pulls back) and y 1390 (bottom, the one who acts). `Figure(~226–255)`.
- Lane labels 2–4 words, 24px LABEL, at lane y + 66.
- Header (the feeling) at y 486 with `beats()`, 32px; it can change mid-reel.
- Round label (YEAR 1 / 3 / 7, a clock, MONDAY / WEDNESDAY / FRIDAY) at y 572, 36px WHITE with a small pop.
- Three rounds, then the end card while the scene keeps running underneath. Never cut to black.
- End card, written by hand in `frame()` like the examples: verdict line 1 at y 262 (28px LABEL), line 2 at y 344
  (48px WHITE), then the source: Arabic (Qur'an) or the English text in 17–20px lines from y ~424, citation 20px
  DIM. (`end_card()` in kit2 is an older layout; don't use it.)
- Timing: `E1` (verdict) ≈ 7.0 s, `E2 = E1 + 1.05` (source), `DUR = E2 + 0.55 + 1.05`.

### B. 8-beat formula reel (`formula.py`)
HOOK → PROMISE → VALUE 1 → OPEN LOOP 1 → VALUE 2 → OPEN LOOP 2 → VALUE 3 → CTA ("3 things…" reels). One figure,
one floor at y 1330, all text in the band above. 18.4 s. Beat times in `T`: hook 0–3 (visible from frame 0),
promise 1.4–3, v1 3–6.7, l1 6.7–7.8, v2 7.8–11.5, l2 11.5–12.6, v3 12.6–16.4, cta 16.4–end.
- `hook(c, t, [line1, line2])`: 46px, at most ~28 characters a line.
- `promise(c, t, line)`: the reason to keep watching.
- `value(c, t, n, TITLE, [sub lines], span)`: "n / 3", title (shrinks to fit), 1–2 sub lines.
- `loop(c, t, line, span)`: one line with a red dot that teases the next value without giving it away.
- `cta(c, t, action, "SEND THIS TO SOMEONE WHO…", "CITATIONS")`.
- Each value gets its own visual event in the same scene, and the scene builds (a scale keeps tipping, a grave
  keeps getting brighter). Examples: `v70_falloff.py`, `v73_heavy.py`, `v75_gohome.py`.

### C. Explainer (no people)
Two labelled lanes that show one idea side by side (`examples/v63_kun.py`).

---

## 5. Engine cheat sheet

- `FIG = Figure(h)`; `j = FIG.solve(pose, x, f, ground=G)` (f = 1 faces right, −1 left; puts the lowest point on
  G); `FIG.draw(c, j, a=alpha, held=fn)` (`held` draws between the far limbs and the head: palms, a phone).
  Joints: `j['head'], j['sh'], j['ash'], j['hip'], j['Lh'], j['Rh'], j['Le'], j['Re'], j['Lk'], j['Lf']…`
- Poses are dicts of angles in degrees, positive = toward the facing direction. Torso `t` is measured from
  straight UP (t=88 bent flat forward, t=−90 lying with the head behind). `hd` is added on top of `t`. Thighs
  `Lth/Rth` and upper arms `Lua/Rua` are measured from straight DOWN (90 = horizontal forward, 180 = straight up).
  Shin = thigh − knee (`Lkn`); forearm = upper arm + elbow (`Lel`). Build with `P(...)` or `dict(BASE, key=val)`.
- Pose library: STAND, STAND_TALL, LOOK_UP, LOOK_DOWN, HAND_HEAD, BOTH_HEAD, BEND, CARRY, SIT, SIT_UP, RECOIL,
  THINK, CROUCH, TAKBIR, QIYAM, RUKU, SUJUD, JULUS (kneeling); kit2 adds DUA_ST (standing du'a), DUA_SIT (du'a on a
  chair), HALF_DUA, SIT_F (on the floor, knees up). Kneeling du'a:
  `dict(JULUS, t=-2, hd=10, Lua=26, Lel=128, Rua=38, Rel=122)`. Lying:
  `P(t=-90, hd=0, Lth=86, Lkn=8, Rth=92, Rkn=4, Lua=86, Lel=0, Rua=94, Rel=0)`. Sitting up in bed:
  `P(t=0, hd=8, Lth=88, Lkn=2, Rth=92, Rkn=4, Lua=20, Lel=20, Rua=24, Rel=20)`.
- Motion: `seg(t, a, b)` (0→1), `ease`, `ease_in`, `ease_out`, `lerp`, `mix(p0, p1, u)`,
  `chain(t, [(t0, pose), …])`, `walk(phase, stride)`,
  `pose, x = walk_to(FIG, t, t0, t1, xa, xb, stride=20, prev=STAND, end=STAND)`,
  `j = with_arms(FIG, pose, x, f, G, {'R': (x, y)}, w)` (arm IK), `shake_head(p, t, t0, t1)`, `palms(c, j, a, size)`.
- Drawing: `text(c, s, x, y, size, color, a, spacing, tf)`, `arabic(c, s, x, y, size, color, a)`,
  `line(c, x0, y0, x1, y1, color, w, a)`, `rect(c, x, y, w, h, color, a, r)`, `burst(c, x, y, r, rot, a)`,
  `light_pool(c, x, y, rx, ry, WARM, a)`, `beam(c, x_top0, x_top1, y_top, x_bot0, x_bot1, y_bot, a, color)`,
  `tint(c, NIGHT, a)`, `beats(c, t, [(t0, t1, TEXT), …], y, size)`, `thought_bubble`, `flower`.
  Colours: WHITE, FAR, LABEL, DIM, RED, WARM, NIGHT.
- Frame recipe: `background(c)` → `pic = record(lambda rc: world(rc, t))` → reflection (`finish(c, pic, i)` in
  formula reels; per lane `c.clipRect(...)` + `reflection(c, pic, G, strength=0.08, fade=60)`) →
  `c.drawPicture(pic)` → text → `vignette(c, 0.5)` → `grain(c, i)`.
- End of each script: `EVENTS = dict(dur=DUR, …every time the sound needs…)` and
  `if __name__ == '__main__': run(frame, 'vNN', N, DUR, EVENTS)`.

---

## 6. Making a reel, step by step

1. **Idea.** Agree the feeling, the two labels (or the three values), the rule of the world and the reveal. Write
   them in the script's docstring.
2. **Verify the source** (section 2) before writing the end card. Quote it exactly.
3. **Write `vNN_slug.py`** next to the engine by copying the closest example. Number reels in order.
4. **Test stills first**: `python3 vNN_slug.py stills 1.0 3.5 …` (10–14 times covering every beat), then
   `python3 tools/sheet.py test/vNN test/vNN_sheet.png "0,200,1080,1500"` (two-lane; use "0,250,1080,1420" for
   formula reels) and look at the sheet. Check that poses read, nothing overlaps (bubbles, props, text), white
   figures don't vanish against light, the rule of the world is visible and the end card is legible. Fix and
   re-test until it's right. Show the person the sheet if they want to approve the look before the full render.
5. **Full render in the background**: `(nohup python3 vNN_slug.py > test/vNN.render.log 2>&1 &)`, then poll:
   `ps -eo pid,args | awk '$2=="python3" && $3=="vNN_slug.py"'` until it prints nothing (don't use `pkill -f`; it
   matches its own shell). Look at the whole video:
   `ffmpeg -v error -y -i out/vNN_silent.mp4 -vf "fps=1.5,crop=1080:1200:0:250,scale=160:-1,tile=10x3" -frames:v 1 test/vNN_full.png`.
6. **Sound**: add `build_vNN()` to `sfx_reels.py` by copying the closest example (`build_v60` … `build_v75`).
   `e = ev('vNN')` loads the events; `m = Mix(D)`; `m.add(signal, t, gain, pan)` (gain ~0.02–0.15, pan −1..1).
   Generators: `room(dur, level)`, `step(soft)`, `cloth(dur)`, `thump(f0, dec, click)`, `pluck(freq)`,
   `whoosh(dur, f0, f1)`, `swell(dur)`, `breath(dur)`, `splash_snd(size)`, `water_run(dur)`, `wind(dur, level)`,
   `crickets(dur)`, `tick()`, `clack(pitch ≤ 4, weight)`, `creak_pull(dur)`, `thunk()`, `puff()`, `rumble(dur)`,
   `rattle(dur)`, `sparkle(dur)`, `beep(freq, dur)`. Pattern: a quiet `room` bed, steps, `cloth` on pose changes,
   a `pluck` for each good outcome, `thump` for impacts, a `swell(2.2)` 0.35 s before the end card; formula reels
   call `formula_beats(m, e)`. Finish with `m.drive = 2.0` and `m.write('out/vNN_audio.wav', peak_db=-2.0)`.
   Run `python3 sfx_reels.py vNN`.
7. **Mux and level**: `python3 tools/finish.py vNN Title` → `out/Title.mp4` at −13 LUFS.
8. **Qur'an reels** also need the recitation (Mishary Alafasy, from everyayah.com):
   - Download `https://everyayah.com/data/Alafasy_128kbps/SSSAAA.mp3` (3-digit surah + 3-digit ayah) into
     `audio_src/hq/`. If this environment can't reach the site, ask the person to download it and attach it.
   - Find the cut: `python3 tools/word_times.py S A` (word-by-word times) and `python3 tools/find_cuts.py <mp3>`.
   - Add a `CFG` entry in `quran_mix.py`: `name`, `file`, `seg=(start, end)` (just the relevant words),
     `start` (when it begins in the reel), optional `fo` (fade), `duck`, `keep_video_len=True`. Time the reel so
     a key recited word lands on its picture.
   - `python3 quran_mix.py vNN` → `out/<name>.mp4`, then `python3 tools/finish.py --file out/<name>.mp4`.
9. **Caption** (section 7), then **deliver**: give the person the MP4 and the caption in whatever way this
   environment shares files, with one short line on what happens in the reel.

Known pitfalls:
- `solve(ground=)` lifts the whole body if any limb points into the floor (arms when lying, legs when sitting on
  a chair). Lying arms: keep `Rua` around 86–100.
- Blending two very different poses gives ugly in-betweens (kneel → stand, sit → lie). Chain through an
  intermediate pose, e.g. `RISE = P(t=22, hd=10, Lth=64, Lkn=92, Rth=18, Rkn=40, Lua=6, Lel=12, Rua=10, Rel=12)`.
- Arabic: write عَلَى rather than عَلَىٰ (the dagger alif breaks the shaping).
- Translate before clipping when you split a shape. Parted water reads better with straight inner walls.
- Long lines run off the frame: check every still.

---

## 7. Captions

Second person ("you"), never first person. Shape:
```
<hook: a question naming the feeling>

<2–3 short lines that open it up>

<the verified ayah or hadith, quoted exactly, with its reference>

Ask yourself:
<question>
<question>
<question>

Send this to <someone specific>.

Follow for more.

#<topic> #<topic> #<page tag> #<tag> #<tag>
```
Give each caption in its own code block so it can be copied in one tap.
