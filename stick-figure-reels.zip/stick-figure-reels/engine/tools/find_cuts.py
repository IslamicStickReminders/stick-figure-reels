"""Print the pauses inside a recitation mp3, to help pick seg=(start, end) for quran_mix.py.
Usage: python3 tools/find_cuts.py audio_src/hq/017023.mp3"""
import os, re, subprocess, sys
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if os.path.exists(os.path.join(HERE, 'bin', 'ffmpeg')):
    os.environ['PATH'] = os.path.join(HERE, 'bin') + os.pathsep + os.environ.get('PATH', '')
err = subprocess.run(['ffmpeg', '-nostats', '-i', sys.argv[1], '-af', 'silencedetect=n=-32dB:d=0.18', '-f', 'null', '-'],
                     capture_output=True, text=True).stderr
for a, b in zip(re.findall(r'silence_start: ([\d.]+)', err), re.findall(r'silence_end: ([\d.]+)', err)):
    print(f'pause {float(a):7.2f} -> {float(b):7.2f}')
