"""Finish a reel: mux picture + sound and level the loudness to -13 LUFS (Instagram-loud, no clipping).

  python3 tools/finish.py vNN Title        out/vNN_silent.mp4 + out/vNN_audio.wav  ->  out/Title.mp4
  python3 tools/finish.py --file out/Title.mp4   re-level a video that already has sound (Qur'an reels after quran_mix)

Run from the engine folder. Prints the final loudness and file size."""
import os, re, subprocess, sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if os.path.exists(os.path.join(HERE, 'bin', 'ffmpeg')):
    os.environ['PATH'] = os.path.join(HERE, 'bin') + os.pathsep + os.environ.get('PATH', '')
TARGET = -13.0


def lufs(path):
    err = subprocess.run(['ffmpeg', '-nostats', '-i', path, '-af', 'ebur128', '-f', 'null', '-'],
                         capture_output=True, text=True).stderr
    return float(re.findall(r'I:\s+(-?[\d.]+) LUFS', err)[-1])


def encode(video, audio, out, gain, reencode_video):
    af = f'volume={gain:.2f}dB,alimiter=limit=0.89:level=false'
    cmd = ['ffmpeg', '-v', 'error', '-y', '-i', video]
    if audio:
        cmd += ['-i', audio]
    cmd += ['-map', '0:v:0', '-map', ('1:a:0' if audio else '0:a:0')]
    if reencode_video:
        cmd += ['-c:v', 'libx264', '-preset', 'slow', '-crf', '18', '-pix_fmt', 'yuv420p']
    else:
        cmd += ['-c:v', 'copy']
    cmd += ['-af', af, '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', out]
    subprocess.run(cmd, check=True)


def main():
    if sys.argv[1] == '--file':
        src = sys.argv[2]
        tmp = src[:-4] + '.leveling.mp4'
        gain = TARGET - lufs(src)
        encode(src, None, tmp, gain, False)
        got = lufs(tmp)
        if abs(got - TARGET) > 0.3:
            encode(src, None, tmp, gain + TARGET - got, False)
        os.replace(tmp, src)
        out = src
    else:
        v, title = sys.argv[1], sys.argv[2]
        video, audio, out = f'out/{v}_silent.mp4', f'out/{v}_audio.wav', f'out/{title}.mp4'
        gain = TARGET - lufs(audio)
        encode(video, audio, out, gain, True)
        got = lufs(out)
        if abs(got - TARGET) > 0.3:
            encode(video, audio, out, gain + TARGET - got, True)
    print(f'{out}: {lufs(out):.1f} LUFS, {os.path.getsize(out) / 1e6:.1f} MB')


if __name__ == '__main__':
    main()
